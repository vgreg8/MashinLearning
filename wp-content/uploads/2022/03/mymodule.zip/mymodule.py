"""
Модуль для поиска элементов в массиве чисел.
============================================

Classes
-------

BinarySearch


Functions
---------
linear
"""

def linear(arr, x):
    """Выполняет линейный поиск по массиву чисел.

    Parameters
    ----------
    arr : {list, ndarray}
        Массив чисел, по которому выполняется поиск.
        
    x : int
        Искомое число.


    Returns
    -------
    i : int
        Индекс искомого числа, если оно присутствует в массиве.

    """
    for i in range(len(arr)):
        if arr[i] == x:
            return i

class BinarySearch:
    """Бинарный поиск по массиву чисел.
    """

    def __init__(self):
        pass

    def srt(self, arr):
        """Сортирует массив чисел в возрастающем порядке.

        Parameters
        ----------
        arr : {list, ndarray}
            Массив для сортировки.


        Returns
        -------
        arr : {list, ndarray}
            Массив, отсортированный в возрастающем порядке.

        """
        arr = sorted(arr)
        return arr

    def check(self, arr, x):
        """Проверяет наличие числа в массиве c помощью алгоритма бинарного поиска.

        Parameters
        ----------
        arr : {list, numpy array}
            Массив чисел, по которому выполняется поиск.
            
        x : int
            Искомое число.


        Returns
        -------
        mid : int
            Индекс числа в отсортированном по возрастанию массиве чисел.
            Возвращает -1, если число не найдено.

        """
        low, high = 0, len(arr)-1

        while low <= high:
            mid = low + (high - low) // 2

            if arr[mid] == x:
                return mid

            elif arr[mid] < x:
                low = mid + 1

            else:
                high = mid - 1

        mid = -1

        return mid